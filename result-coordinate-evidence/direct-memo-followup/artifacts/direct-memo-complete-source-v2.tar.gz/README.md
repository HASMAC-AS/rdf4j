# Complete source for the direct lazy Value memo experiment

This archive contains every changed production class in full, the two new test classes, the experimental launcher and statistics helper, and the generators, contract runners, and prospective benchmark/analyzer sources. It contains no abbreviated or placeholder code.

The source baseline is HASMAC-AS/rdf4j commit 97284c5229fc826b156275b15f105aac4dd801d6, tree 4db5b366c00c68f5e89c7301612b5a821fc0e5d0. The tested candidate is result-coordinate-evidence/direct-memo-followup/runtimes/identity-witness-v2. The exact six compiled prefix classes are preserved separately in identity-witness-v2-prefix.tar.gz. The benchmark uses the unchanged preserved common128 classpath, Java 25.0.5+8, and the protocol included here; this source archive is not a standalone RDF4J distribution or a replacement for its Maven dependencies.

## Inspect or apply the feature

The complete-production-source directory contains four production files and the two new test files at their intended repository paths. The adjacent direct-memo-source.patch includes all four production changes, including the statistics helper required by the memo. It passed git apply --check against the selected baseline. Applying it is optional; the experiment itself compiled an isolated prefix and left selected production sources unchanged.

The feature is off by default. The direct treatment uses both:

    -Drdf4j.lmdb.nativeValueMemo.enabled=true
    -Drdf4j.lmdb.resultCoordinateTransport=off

Coordinate transport has its own existing property and defaults to dense on the selected branch. The direct memo does not consult factor coordinates; the second setting also removes producer transport work in the tested treatment. Controls share the same compiled prefix and ownership implementation.

## Correctness and memory scope

The tested table adds an identity witness to the four-array proposal, preserving invalidation when the dictionary ID, revision number, or owner changes without a semantic-version change. Standalone reads still use ordinary lazyValue when a native dictionary wrapper needs its ownership handoff. Sail capture validates the supplied exposure token.

The candidate passed 20 table cases, 12 integration cases, 106 existing disabled-feature cases, and 8 enabled-feature real-query lifetime/bag cases in both IR tiers. The separate four-array diagnostic intentionally fails three identity-invalidation cases and must never be substituted for the candidate.

The ledger reserves the five arrays and wide-row scratch. It does not account for strongly retained wrappers, decoded payloads, or captured revision capabilities. The original first 8,192-probe cutoff also remains deliberately unchanged. This is an experimental implementation, not a production-memory guarantee.

The full Git checkpoint preserves raw reports and command/source/class hashes. Follow contracts/VALIDATION.md and benchmark/PROTOCOL.md there for the exact workspace commands. Each archive member is listed and SHA-256-pinned in SOURCE-CONTENTS.json.
