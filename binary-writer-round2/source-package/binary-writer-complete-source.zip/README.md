# RDF4J binary query result writer: complete changed Java sources

Source commit: `c03171474130c67ca2eed2b78e3cc82cd4fba345`
Source tree: `32efd9174b509fd46a0c0c63168eaff03c69dd43`
Incremental patch base: `741b9389538e80214075692439a8cd25a8a9ae84`
Cumulative patch base: `5434e51194e6c2e1aa745e5d65a4c998918d6073`

This archive contains the complete source-commit version of every Java file
changed relative to the cumulative base, at its original repository path.
It is a changed-source package, not a complete RDF4J checkout. Any deleted Java
paths are recorded in manifest.json and have no source-commit file to include.
Every source byte was read through git show; local uncommitted files are excluded.

manifest.json records each complete source's SHA-256 and size, both patch hashes,
the exact commits, and the source tree reproduced by each patch verification.
The incremental and cumulative patches contain only git diff output, including
all changed paths, and are alternatives for their respective starting commits.
Each was checked and applied in an isolated temporary index; its resulting tree
matched the source commit. The repository working tree, index, and refs were
not changed by verification. ZIP CRCs and every archived source byte were checked.

Archive timestamps are fixed for reproducibility. Benchmark evidence is not
included in this package.
