Complete changed Java sources for RDF4J binary writer optimization.
Base: 5434e51194e6c2e1aa745e5d65a4c998918d6073
Copy these paths over a checkout of that revision, or apply the accompanying diff-only patch with git apply.
All three changed files are included in full. The benchmark/evidence bundle is separate.
